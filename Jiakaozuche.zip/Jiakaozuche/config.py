# coding: utf-8
import os
basedir = os.path.abspath(os.path.dirname(__file__))


class Config():
    #邮件设置
    #MAIL_SERVER = 'smtp.qq.com'
    #MAIL_PORT = 587
    #MAIL_USE_TLS = True
    #MAIL_USERNAME = '907926646@qq.com'
    #MAIL_PASSWORD = 'rtnhvwqfsglvbdbf'
    MAIL_SERVER = 'smtpdm.aliyun.com'
    MAIL_PORT = 25
    MAIL_USE_TLS = False
    MAIL_USERNAME = 'notice@zuche.com'
    MAIL_PASSWORD = 'rtnhvwq'
    MAIL_SUBJECT_PREFIX = u'[驾考租车网]'
    MAIL_SENDER = u'驾考租车网 <notice@jiakaozuche.com>'
    #初始化coin设置
    COIN_REGISTER_GET = 5
    COIN_SIGN_GET = 1
    COIN_RENLING = 2
    COIN_SUBMIT_COST = 2
    COIN_NOT_COMENT_COST = 100
    COIN_VIP = 30

    CACHE_TYPE = 'simple'
    #分页设置
    ARTICLES_PER_PAGE = 10
    SITEMAP_PER_PAGE = 1000
    #CACHE_TYPE='redis'
    #CACHE_REDIS_HOST='127.0.0.1'
    #CACHE_REDIS_PORT=6379
    #CACHE_REDIS_DB=''
    #CACHE_REDIS_PASSWORD=''
    # DEBUG = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    # SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    SQLALCHEMY_RECORD_QUERIES = True
    SQLALCHEMY_POOL_SIZE = 50
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:root@localhost/car'
    #SQLALCHEMY_DATABASE_URI = 'mysql://root:root@127.0.0.1/jia'
    #SQLALCHEMY_DATABASE_URI = 'mysql://root:root@127.0.0.1/jia0'
    #SQLALCHEMY_DATABASE_URI = 'mysql://cdb_outerroot:newfarry16ayw@589ec84f69127.sh.cdb.myqcloud.com:8229/jia0'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    SECRET_KEY = 'secret@key!to $prect &from )csrf@'
    WTF_CSRF_SECRET_KEY = 'randomt@key!tey f$or for!m' # for csrf protection
    # Take good care of 'SECRET_KEY' and 'WTF_CSRF_SECRET_KEY', if you use the
    # bootstrap extension to create a form, it is Ok to use 'SECRET_KEY',
    # but when you use tha style like '{{ form.name.labey }}:{{ form.name() }}',
    # you must do this for yourself to use the wtf, more about this, you can
    # take a reference to the book <<Flask Framework Cookbook>>.
    # But the book only have the version of English.

    @staticmethod
    def init_app(app):
        pass