var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?cb61d88d2bffc747f2e5e8be672c3751";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);
  console.log("ok");
})();
